import React, { Component } from 'react';
import  './header.css';

class Header extends Component{
    render(){
        return(
            <div>
                <header>
    Partner Engagement Portal
    </header>
                </div>

        );
    }
}
export default Header;
