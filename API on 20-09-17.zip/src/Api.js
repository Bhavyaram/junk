import React, { Component } from 'react'
import Header from './Header/header';
import Input from './Textbox/input';
import Footer from './Footer/footer';
import Tabbutton from './Tab/tabbuttons';
import SubmitButton from './Button/submitbutton';
import Dropdown from './Dropdown/dropdown';
import Result from './Result/result';
import './style.css';
//import In from './in';
var temp = [''];
class Api extends Component {
    constructor() {
        super();
        this.state = {
            data: [''],
            temp :['']
        }
        this.click = this.click.bind(this);
    }
    componentDidMount() {
        fetch("http://demo8329762.mockable.io/bhavya")
            .then((Response) => Response.json())
            .then((findResponse) => {
                this.setState({ data: findResponse })
                console.log(findResponse)
            }
            )

    }

    click(e) {
        e.preventDefault();
        this.setState({ temp: this.state.data });
        console.log(temp.BussinessName)
    }


    render() {
        return (<div className="container">
            <Header />
            <div className="Wrapper">
                <fieldset>
                    <div className="Fieldset">
                        <div>
                            <h3>Register</h3>
                        </div>
                        <div className="Tab">
                            <Tabbutton value="Admin" className="adminButton" />
                            <Tabbutton value="Partner" className="partnerButton" />
                        </div>
                        <div>
                            <h5>Make sure you are in the right user selection screen, before filling.</h5>
                        </div>
                        <form>
                            <div>
                                <div>
                                 
                                    <Input placeholder="Bussiness Name" className="firsttextbox" value={this.state.temp.BussinessName} />
                                    <Input placeholder="Trading Name" className="firsttextbox" value={this.state.temp.TradingName}/>
                                </div>
                                <div><Input placeholder="Phone number" className="firsttextbox"  value={this.state.temp.PhoneNumber}  />
                                    <Input placeholder="eMail ID" className="firsttextbox" value={this.state.temp.EmailId}  />
                                </div>
                                <div className="drop">
                                    <Input placeholder="Address" className="textbox" value={this.state.temp.Address} />
                                    <Input placeholder="Street" className="textbox" value={this.state.temp.Street}/>
                                    <Dropdown value={this.state.temp.Country} />
                                </div>
                                <div className="checkbox">
                                    <label><input type="checkbox" />Decision maker same as details given</label>
                                </div>
                                <div>
                                    <Input placeholder="Decision Maker Name" className="textbox" value={this.state.temp.DecisionMakerName} />
                                    <Input placeholder="Phone number" className="textbox" value={this.state.temp.PhoneNumber1}/>
                                    <Input placeholder="eMail ID" className="textbox" value={this.state.temp.EmailId1}/>
                                </div>
                                <div>
                                    <SubmitButton click={this.click}/>
                                    <a className="Cancel" href="abc">Cancel</a> </div>
                                <div className="cite">
                                    <cite>* The details will be sent to eBay for verification and approval. Once on approval, login credentials will be shared to your registered email ID.</cite>
                                </div>
                            </div>
                        </form>
                    </div>
                </fieldset>
                <Footer />
            </div >
        </div >
        );
    }
}


export default Api;

