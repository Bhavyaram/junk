import React, { Component } from 'react';
import './tabbutton.css';

class Tabbutton extends Component{
    render(){
        return(
                <input type="button" value={this.props.value} className={this.props.className}/>
        );
    }
}
export default Tabbutton;