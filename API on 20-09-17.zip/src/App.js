import React, { Component } from 'react'
import Api from './Api';

class App extends Component {
  render() {
    return (
      <Api/>
    );
  }
}

export default App;
