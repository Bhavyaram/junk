import React, {Component} from 'react'
class Footer extends Component
{
render(){
return(
<div>
<footer>
                 <span className="Fb">
                <h6 className="below">
                            
<p className="before">ebay</p><span className="Fbusiness"> for business</span>
</h6> 
<p className="copyright"> © ebay 2017 </p>  
</span>                             
<span className="Fright"><p className = "TandC"><a href="#"> Terms&Conditions </a> <span>|</span><a href="#">PrivacyPolicy </a> </p></span>
</footer>
</div>                               

);
}
}
export default Footer;
