import React, { Component } from 'react';
class Button2 extends Component {
  render() {
    return (
      <div>
 <input type="button" value="{this.props=value}"/>
       </div>
        );
  }
}
export default Button2;