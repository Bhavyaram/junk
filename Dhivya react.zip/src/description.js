import React, { Component } from 'react';
class Description extends Component {
  render() {
    return (
      <div>
  <div className="description"> <textarea rows="7" cols="50" placeholder="Description"></textarea> </div>
       </div>
        );
  }
}
export default Description;
