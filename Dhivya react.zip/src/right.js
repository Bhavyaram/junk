import React, { Component } from 'react';
import TextField1 from './textfield1';
import Description from './description';
import Button from './button';
class Right extends Component {
  render() {
    return (
     <div>
         <div className="high"><p align="right">High Important</p></div>

      <TextField1 placeholder="Content"/>
<Description/>
<Button value="submit"/>


</div>
        );
  }
}
export default Right;
