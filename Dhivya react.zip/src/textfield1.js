import React, { Component } from 'react';
class TextField1 extends Component {
  render() {
    return (
      <div>
  <input  className="textfield1" type="text" placeholder={this.props.placeholder} />
       </div>
        );
  }
}
export default TextField1;