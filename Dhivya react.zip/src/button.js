import React, { Component } from 'react';
class Button extends Component {
  render() {
    return (
      <div>
<button  type="submit" value={this.props.value}></button>
       </div>
        );
  }
}
export default Button;
