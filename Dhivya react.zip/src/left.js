import React, { Component } from 'react';
import TextField1 from './textfield1';
import Button from './button';
class Left extends Component {
  render() {
    return (

   
     </div>
     );
  }
  
            
      
}
export default Left;