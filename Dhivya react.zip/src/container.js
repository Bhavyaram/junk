import React, { Component } from 'react';
import TextField1 from './textfield1';
import Button from './button';
import Description from './description';
import Footer from './footer';
class Container extends Component {
  render() {
    return (
      <div>
   <fieldset>
       <div className="left" >
<p className="upload">Upload Content</p>        
<p className="doc"><strong>Document Type</strong></p>
<p className="pri">Pricing Partly</p>
<TextField1 placeholder="Upload"/>
<p className="passage"><i>*Only Lorem Ipsum files format of
 sixe X would be uploaded Lorem Ipsum, Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum</i></p>

<Button value="Upload"/>
</div>
<div className="right">
<div className="high"><p align="right">High Important</p></div>

<TextField1 placeholder="Submit"/>
<Description/>
<Button value="Submit"/>
<a className="cancel" href="#">Cancel</a>
  </div>
   </fieldset>
     <Footer/>
     </div>
        );
  }
}
export default Container;