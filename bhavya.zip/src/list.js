import React, { Component } from 'react';
import './submitbutton.css';
class List extends Component {
    constructor() {
        super();
        this.state = {
            item:
            ['bhavya', 'cognizant', 'chennai']
        }
    }
    render() {
        return (
            <div>
                <ul>
                    {
                        this.state.item.map(function (items){
                       return < li key = {items} >
                       {items} 
                
                      </li>
                })}
                      </ul>
                  </div >
        );
    }
}
export default List;