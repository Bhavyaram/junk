import React, { Component } from 'react';
import SubmitButton from './submitbutton';
import Input from './input';
class Result extends Component {
    constructor(props){
        super(props);
        this.state={value:'this.props.value'}   
        this.click=this.click.bind(this);
    }
click() {
        this.setState({value:this.props.BN});
        console.log({value:this.props.value})
    }
    render() {
        return (  
            <div>
        <SubmitButton click={this.click}/>
        <div>
        <Input value={this.state.BN}/>
        </div>
        </div>
        );
    }
}
export default Result;