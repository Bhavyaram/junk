import React, { Component } from 'react';
class SubmitButton extends Component{
    render(){
        var myStyle = {
						backgroundcolor:' #FF0000',
						border:'30px',
						padding:'15px',
						width:'15%',
						borderradius:'5px' 
      }
        return(
                <button style={myStyle}></button>
        );
    }
}
export default SubmitButton;