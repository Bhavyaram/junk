import React, { Component } from 'react'
import Header from './header';
import Input from './input';
import Footer from './footer';
import Button from './button';
import SubmitButton from './submitbutton';
import './style.css';
class Partner extends Component{
    render(){
        return(<div className="container">
        <Header />
        <div className="Wrapper">
          <fieldset>
            
              <div>
                <h3>Register</h3>
              </div>
              <div className="Tab">
                <Button className="adminButton"/>
                <Button className="partnerButton"/>
                </div>           
            <div>
              <h5>Make sure you are in the right user selection screen, before filling.</h5>
            </div>
            <form>
            <div>
            <div><Input placeholder="Bussiness Name"/>
            <Input placeholder="Trading Name"/>
            </div>
            <div><Input placeholder="Phone number"/><Input placeholder="eMail ID"/></div>
            <div className="textbox"><Input placeholder="Address"/><Input placeholder="Street"/><Input placeholder="Country"/></div>
            <div className="checkbox">
              <label><input type="checkbox" />Decision maker same as details given</label>
            </div>
            <div>
              <Input placeholder="Decision Maker Name"/><Input placeholder="Phone number"/><Input placeholder="eMail ID"/>
              </div>
            <div>
                <SubmitButton/>
            <a className="Cancel" href="#">Cancel</a> </div>
            <div><cite>* The details will be sent to eBay for verification and approval. Once on approval, login credentials will be shared to your registered email ID.</cite>
            </div>
          </div>
          </form>
          </fieldset>
          <Footer />
        </div >
      </div >
        );
    }
}
export default Partner;