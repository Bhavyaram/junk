import React, { Component } from 'react';

import Partner from './partner';

class App extends Component {
  render() {
    return (
      <Partner/>
    );
  }
}

export default App;
