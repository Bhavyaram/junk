import React, { Component } from 'react'
import Header from './Header/header';
import Input from './Textbox/input';
import Footer from './Footer/footer';
import Tabbutton from './Tab/tabbuttons';
import SubmitButton from './Button/submitbutton';
import Dropdown from './Dropdown/dropdown';
import Result from './Result/result';
import './style.css';
class Partner extends Component {
    constructor() {
        super();
        this.state = { BN: '', TN: '', PN: '', Email: '', Add: '', STREET: '', DN: '', Country: '', xvalue: '' }
        this.click = this.click.bind(this);
    }
    click(e) {
        e.preventDefault();
        this.setState({
            xvalue:
            [this.state.BN, this.state.TN, this.state.PN, this.state.Email, this.state.Add, this.state.STREET, this.state.DN ,this.state.country]
        });

    }
    render() {
        return (<div className="container">
            <Header />
            <div className="Wrapper">
                <fieldset>
                    <div className="Fieldset">
                        <div>
                            <h3>Register</h3>
                        </div>
                        <div className="Tab">
                            <Tabbutton value="Admin" className="adminButton" />
                            <Tabbutton value="Partner" className="partnerButton" />
                        </div>
                        <div>
                            <h5>Make sure you are in the right user selection screen, before filling.</h5>
                        </div>
                        <form>
                            <div>
                                <div>
                                 
                                    <Input placeholder="Bussiness Name" className="firsttextbox" _onchange={e => this.setState({ BN: e.target.value })}/>
                                    <Input placeholder="Trading Name" className="firsttextbox" _onchange={e => this.setState({ TN: e.target.value })}/>
                                </div>
                                <div><Input placeholder="Phone number" className="firsttextbox" _onchange={e => this.setState({ PN: e.target.value })}/>
                                    <Input placeholder="eMail ID" className="firsttextbox"  _onchange={e => this.setState({ Email: e.target.value })}/>
                                </div>
                                <div className="drop">
                                    <Input placeholder="Address" className="textbox" _onchange={e => this.setState({ Add: e.target.value })}/>
                                    <Input placeholder="Street" className="textbox" _onchange={e => this.setState({ STREET: e.target.value })}/>
                                    <Dropdown/>
                                </div>
                                <div className="checkbox">
                                    <label><input type="checkbox" />Decision maker same as details given</label>
                                </div>
                                <div>
                                    <Input placeholder="Decision Maker Name" className="textbox" _onchange={e => this.setState({ DN: e.target.value })}/>
                                    <Input placeholder="Phone number" className="textbox" _onchange={e => this.setState({ PN: e.target.value })}/>
                                    <Input placeholder="eMail ID" className="textbox" _onchange={e => this.setState({ Email: e.target.value })}/>
                                </div>
                                <div>
                                    <SubmitButton click={this.click}/>
                                    <a className="Cancel" href="abc">Cancel</a> </div>
                                <div className="cite">
                                    <cite>* The details will be sent to eBay for verification and approval. Once on approval, login credentials will be shared to your registered email ID.</cite>
                                </div>
                                 <Result xvalue={this.state.xvalue}/>
                            </div>
                        </form>
                    </div>
                </fieldset>
                <Footer />
            </div >
        </div >
        );
    }
}
export default Partner;