import React, { Component } from 'react';
import './footer.css';
class Footer extends Component{
    render(){
        return(
            <div>
               <span className="ebay"> ebay</span> <span className="ebayforbusiness">for business</span>  <span className="ebayyear">© ebay 2017</span>
               <span className="TC"> 
                   <a href="#">Terms & conditions </a><span>|</span><a href="#"> Privacy policy </a>
                   </span> 
            </div>
        );
    }
}
export default Footer;