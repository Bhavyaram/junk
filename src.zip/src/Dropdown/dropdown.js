import React, { Component } from 'react';
import './dropdown.css';

class Dropdown extends Component{
render(){
return(
 <span className="List"> 
<input list="Country" placeholder="Country" className={this.props.className}  />
                                    <datalist id="Country" >
                                        <option value="India" />
                                        <option value="Australia" />
                                        <option value="Korea" />
                                        <option value="Japan" />
                                   </datalist>
                                   </span>
                                   
);
}
}
export default Dropdown;