import React, { Component } from 'react';
import './result.css';
class Result extends Component {   
    render() {
        return (  
            <div className="result">
              
            
                                <label>BN:{this.props.xvalue[0]}</label><br/>
                                 <label>TN:{this.props.xvalue[1]}</label><br/>
                                  <label>PN:{this.props.xvalue[2]}</label><br/>
                                   <label>Email:{this.props.xvalue[3]}</label><br/>
                                   <label>Add:{this.props.xvalue[4]}</label><br/>
                                   <label>Street:{this.props.xvalue[5]}</label><br/>
                                   <label>DN:{this.props.xvalue[6]}</label><br/>
                                   <label>DPN:{this.props.xvalue[2]}</label><br/>
                                   <label>DEmail:{this.props.xvalue[3]}</label><br/>
                                   </div>                                
                                
        );
    }
}
export default Result;