import React, { Component } from 'react';

class Footer extends Component{
    render(){
        return(
            <div className="Footer">
               <p className="ebay"> ebay</p> <p className="ebayforbusiness">for business</p>  <p className="ebayyear">© ebay 2017</p>
               <p className="TC"> 
                   <a href="abc">Terms & conditions </a><span>|</span><a href="abc"> Privacy policy </a>
                   </p> 
            </div>
        );
    }
}
export default Footer;