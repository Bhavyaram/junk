import React, { Component } from 'react';

class Textbox extends Component {
    render() {
        return (                                             
                         <input type="text" placeholder={this.props.placeholder} className={this.props.className}/>                                                              
        );
    }
}
export default Textbox;