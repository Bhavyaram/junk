import React, { Component } from 'react';
import './submitbutton.css';
class SubmitButton extends Component{
    render(){
        return(
               <span><input type="submit" value="SUBMIT"/></span>
        );
    }
}
export default SubmitButton;