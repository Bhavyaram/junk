import React, { Component } from 'react';
import PAGE1 from './page1';


class Navi extends Component {
  
  render() {
    return (
      <navigator initialRoute= {{id :'PAGE1'}}
      renderScene = {this.navigatorfunc}/>
    );
  }
  navigatorfunc(route, navigator){
switch(route.id){
  case 'PAGE1':
  return(<PAGE1 navigator = {navigator}/>);
  default:
  return (<p>oops....</p>);
}
  }
}

export default Navi;
