import React, { Component } from 'react'
import Header from './header';
import Input from './input';
import Footer from './footer';
import Tabbutton from './tabbuttons';
import Textbox from  './secondtextbox';
import Result from './result';
import SubmitButton from './submitbutton';
import './style.css';
class Main2 extends Component {
    constructor() {
        super();
        this.state = {BN: 'abc' ,TN:'def', PN:'' ,Email:'',Add:'',STREET:'manapakkam main road',DN:'',Country:'' ,xvalue:'srija'}
      this._onchange1=this._onchange1.bind(this);
        this._onchange2=this._onchange2.bind(this);
          this._onchange3=this._onchange3.bind(this);
            this._onchange4=this._onchange4.bind(this);
            this._onchange5=this._onchange5.bind(this);
        this._onchange6=this._onchange6.bind(this);
        this._onchange7=this._onchange7.bind(this);
        this._onchange8=this._onchange8.bind(this);
        this.click=this.click.bind(this);
    }
   _onchange1(e){
      this.setState({BN:e.target.value})
         console.log(this.state.BN);
   }
   _onchange2(e){
      this.setState({TN:e.target.value})
   }
   _onchange3(e){
      this.setState({PN:e.target.value})
   }
   _onchange4(e){
      this.setState({Email:e.target.value})
   }
   _onchange5(e){
      this.setState({Add:e.target.value})
   }
    _onchange6(e){
      this.setState({STREET:e.target.value})
   }
    _onchange7(e){
      this.setState({DN:e.target.value})
   }
   _onchange8(e){
      this.setState({Country:e.target.value})
   }
  
   
   
    click(e)
   {
     e.preventDefault();
     console.log(e.preventDefault());
    this.setState({
        xvalue:
        [this.state.BN , this.state.TN , this.state.PN ,this.state.Email,this.state.Add,this.state.STREET,this.state.DN ]
    });

   }
    
    render() {
        return (<div className="container">
            <Header />
            <div className="Wrapper">
                <fieldset>
                    <div className="Fieldset">
                        <div>
                            <h3>Register</h3>
                        </div>
                        <div className="Tab">
                            <Tabbutton value="Admin" className="adminButton" />
                            <Tabbutton value="Partner" className="partnerButton" />
                        </div>
                        <div>
                            <h5>Make sure you are in the right user selection screen, before filling.</h5>
                        </div>
                        <form>
                            <div>
                                <div><Input placeholder="Bussiness Name"  className="firsttextbox"  value={this.state.BN} _onchange={this._onchange1}/>
                                    <Input  placeholder="Trading Name" className="firsttextbox"  value={this.state.TN} _onchange={this._onchange2} />
                                    <Input  placeholder="Phone number" className="firsttextbox"  value={this.state.PN} _onchange={this._onchange3}/>
                                     <Input  placeholder="eMail ID" className="firsttextbox"  value={this.state.Email} _onchange={this._onchange4}/>
                                     <Textbox  placeholder="Address" className="textbox"  value={this.state.Add} _onchange={this._onchange5}/>
                                     <Textbox placeholder="Street" className="textbox"  value={this.state.STREET} _onchange={this._onchange6}/>
                                     <input  placeholder="Country" list="Country" placeholder="Country" _onchange={this._onchange8}/>
                                    <datalist id="Country">
                                        <option value="India" />
                                        <option value="Australia" />
                                        <option value="Korea" />
                                        <option value="Japan" />
                                    </datalist>
                                     <Textbox   placeholder="Decision Maker Name" className="textbox"  value={this.state.DN} _onchange={this._onchange7}/>
                                     <Textbox placeholder="Phone number" className="textbox"  value={this.state.PN} _onchange={this._onchange3}/>
                                     <Textbox  placeholder="eMail ID" className="textbox"  value={this.state.Email} _onchange={this._onchange4}/>
                         
                                </div>
                             <SubmitButton click={this.click}/>
                             <Result xvalue={this.state.xvalue}/>
                                </div>
                        
                        </form>
                    </div>
                </fieldset>
                <Footer />
            </div >
        </div >
        );
    }
}
export default Main2;