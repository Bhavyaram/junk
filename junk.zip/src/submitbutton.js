import React, { Component } from 'react';
import './submitbutton.css';
class SubmitButton extends Component {
   
    render() {
        return (
           <button onClick= {this.props.click}>press here</button>
        );
    }
}
export default SubmitButton;