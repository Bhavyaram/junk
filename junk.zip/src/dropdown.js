import React, { Component } from 'react';


class Dropdown extends Component{
render(){
return(
  
<input list="Country" placeholder="Country" className={this.props.className} onClick={this.props._onclick} />
                                    <datalist id="Country">
                                        <option value="India" />
                                        <option value="Australia" />
                                        <option value="Korea" />
                                        <option value="Japan" />
                                   </datalist>
                                   
);
}
}
export default Dropdown;