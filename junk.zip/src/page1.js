import React, { Component } from 'react';
import List from './list';


class PAGE1 extends Component {
  render() {
    return (
        <div>
  <p>hello</p>
  <button onClcik={()=>this.props.navigator.push({id:'PAGE1'})}> go to page1</button>
  </div>
    );
  }
}

export default PAGE1;
