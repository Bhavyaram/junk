import React, { Component } from 'react'
import Header from './header';
import Input from './input';
import Footer from './footer';
import Tabbutton from './tabbuttons';
import Textbox from  './secondtextbox';


import './style.css';
class Main extends Component {
    constructor() {
        super();
        this.state = { BN: 'developer' ,TN:'Ebay', PN:'9850123654' ,Email:'abc@gmail.com',Add:'DNo:5-8 jains avantika',STREET:'manapakkam main road',DN:'bhavya'}
    }
    
    render() {
        return (<div className="container">
            <Header />
            <div className="Wrapper">
                <fieldset>
                    <div className="Fieldset">
                        <div>
                            <h3>Register</h3>
                        </div>
                        <div className="Tab">
                            <Tabbutton value="Admin" className="adminButton" />
                            <Tabbutton value="Partner" className="partnerButton" />
                        </div>
                        <div>
                            <h5>Make sure you are in the right user selection screen, before filling.</h5>
                        </div>
                        <form>
                            <div>
                                <div><Input  className="firsttextbox"  value={this.state.BN} />
                                    <Input  className="firsttextbox"  value={this.state.TN} />
                                    <Input  className="firsttextbox"  value={this.state.PN} />
                                     <Input  className="firsttextbox"  value={this.state.Email} />
                                     <Textbox  className="textbox"  value={this.state.Add}/>
                                     <Textbox  className="textbox"  value={this.state.STREET}/>
                                     <Textbox  className="textbox"  value={this.state.DN}/>
                                </div>
                            <div className="color">
                                <label> BusinessName:{this.state.BN}</label><br/>
                                 <label> TradingName:{this.state.TN}</label><br/>
                                  <label> PhoneNumber:{this.state.PN}</label><br/>
                                   <label>Email:{this.state.Email}</label><br/>
                                   <label>Address:{this.state.Add}</label><br/>
                                   <label>Street:{this.state.STREET}</label><br/>
                                   <label>DN:{this.state.DN}</label><br/>
                                   <label> PhoneNumber:{this.state.PN}</label><br/>
                                   <label>Email:{this.state.Email}</label>
                                </div>
                                </div>
                        
                        </form>
                    </div>
                </fieldset>
                <Footer />
            </div >
        </div >
        );
    }
}
export default Main;