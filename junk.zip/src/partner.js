import React, { Component } from 'react'
import Header from './header';
import Input from './input';
import Footer from './footer';
import Tabbutton from './tabbuttons';
import SubmitButton from './submitbutton';
import Textbox from './secondtextbox';

import './style.css';
class Partner extends Component {
    render() {
        return (<div className="container">
            <Header />
            <div className="Wrapper">
                <fieldset>
                    <div className="Fieldset">
                        <div>
                            <h3>Register</h3>
                        </div>
                        <div className="Tab">
                            <Tabbutton value="Admin" className="adminButton" />
                            <Tabbutton value="Partner" className="partnerButton" />
                        </div>
                        <div>
                            <h5>Make sure you are in the right user selection screen, before filling.</h5>
                        </div>
                        <form>
                            <div>
                                <div><Input placeholder="Bussiness Name" className="firsttextbox" />
                                    <Input placeholder="Trading Name" className="firsttextbox" />
                                </div>
                                <div><Input placeholder="Phone number" className="firsttextbox" />
                                    <Input placeholder="eMail ID" className="firsttextbox" />
                                </div>
                                <div><Textbox placeholder="Address" className="textbox" />
                                    <Textbox placeholder="Street" className="textbox" />
                                    <input list="Country" placeholder="Country" />
                                    <datalist id="Country">
                                        <option value="India" />
                                        <option value="Australia" />
                                        <option value="Korea" />
                                        <option value="Japan" />
                                    </datalist>
                                </div>
                                <div className="checkbox">
                                    <label><input type="checkbox" />Decision maker same as details given</label>
                                </div>
                                <div>
                                    <Textbox placeholder="Decision Maker Name" className="textbox" />
                                    <Textbox placeholder="Phone number" className="textbox" />
                                    <Textbox placeholder="eMail ID" className="textbox" />
                                </div>
                                <div>
                                    <SubmitButton />
                                    <a className="Cancel" href="#">Cancel</a> </div>
                                <div className="cite">
                                    <cite>* The details will be sent to eBay for verification and approval. Once on approval, login credentials will be shared to your registered email ID.</cite>
                                </div>
                            </div>
                        </form>
                    </div>
                </fieldset>
                <Footer />
            </div >
        </div >
        );
    }
}
export default Partner;