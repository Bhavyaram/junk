import React, { Component } from 'react';

import Main2 from './main_with_onchange';

class App extends Component {
  render() {
    return (
     
      <Main2/>
      
                   
    );
  }
}

export default App;
