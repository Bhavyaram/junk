import React, { Component } from 'react';
import './submitbutton.css';
class SubmitButton extends Component{
    render(){
        return(
                <button></button>
        );
    }
}
export default SubmitButton;