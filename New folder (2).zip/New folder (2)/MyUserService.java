package com.myuserservice;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/myuserservice")
public class MyUserService {

	@GET
	   @Path("/users/{userid}")
	   @Produces(MediaType.APPLICATION_JSON)
	   public String getUserName(@PathParam("userid") int userid){
	      return "CTS";
	   }
	
	
	
	   @GET
	   @Path("/users")
	   @Produces(MediaType.APPLICATION_JSON)
	   public User getUserName(){
		  User u = new User();
		  u.setUsername("Senthil");
	      return u;
	   }
	   
	   
	   @GET
	   @Path("/users1")
	   @Produces(MediaType.APPLICATION_XML)
	   public User getUserName1(){
		  User u = new User();
		  u.setUsername("Senthil");
	      return u;
	   }
	
	
}

