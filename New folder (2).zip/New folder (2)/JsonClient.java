import java.util.HashMap;

import org.codehaus.jackson.map.ObjectMapper;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import com.test.emp.Emp1;


public class JsonClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String URL1 = "http://localhost:8080/MyRestService/svc/EmpService1/emp1";
			try {
	            
	            
	         
	            ClientConfig clientConfig = new DefaultClientConfig();
	            Client client = Client.create(clientConfig);
	            WebResource webResource = client.resource(URL1);
	            
	            
	            String input = "{\"mymap\" : {\"name\"   : \"211222\",\"profession\" : \"Engineer Level 3\"}}";
	            System.out.println("input " + input);
	          
	            ClientResponse response = webResource.accept("application/json")
	                    .type("application/json").post(ClientResponse.class, input);
	            
	           
	            if (response.getStatus() != 200) {
	                throw new RuntimeException("Failed : HTTP error code : "+
	                		response.getStatus());
	            }
	            
	            String u = response.getEntity(String.class);
	            System.out.println(" String request response" + u.toString());
	      
	        } catch (Exception e) {
	            e.printStackTrace();
	        }   

			
			 String URL12 = "http://localhost:8080/MyRestService/svc/EmpService1/emp1";
				try {
		            
		            
		         
		            ClientConfig clientConfig = new DefaultClientConfig();
		            Client client = Client.create(clientConfig);
		            WebResource webResource = client.resource(URL12);
		 
		            Emp1 pd = new Emp1();
		            HashMap<String,String> mymap = new HashMap<String,String>(); 
		            		mymap.put("11", "222");
		            pd.setMymap(mymap);
		            ObjectMapper ma1 = new ObjectMapper();
		            String in = ma1.writeValueAsString(pd);
		            
		         
		            ClientResponse response = webResource.accept("application/json")
		                    .type("application/json").post(ClientResponse.class, in);
		            
		           
		            if (response.getStatus() != 200) {
		                throw new RuntimeException("Failed : HTTP error code : "+
		                		response.getStatus());
		            }
		            
		             String u = response.getEntity(String.class);
		             System.out.println(" Object as string request - response " + u.toString());
		      
		        } catch (Exception e) {
		            e.printStackTrace();
		        }   
			
				
				
				
			 String URL11 = "http://localhost:8080/MyRestService/svc/EmpService1/emp2";
				try {
		            
		            
		         
		            ClientConfig clientConfig = new DefaultClientConfig();
		            clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
		            Client client = Client.create(clientConfig);
		            WebResource webResource = client.resource(URL11);
		            
		            
		            Emp1 pd = new Emp1();
		            HashMap<String,String> mymap = new HashMap<String,String>(); 
		            		mymap.put("44", "333");
		            pd.setMymap(mymap);
		          
		            
		        
		            ClientResponse response = webResource.accept("application/json")
		                    .type("application/json").post(ClientResponse.class, pd);
		            
		           
		            if (response.getStatus() != 200) {
		                throw new RuntimeException("Failed : HTTP error code : "+
		                		response.getStatus());
		            }
		            
		            Emp1 u = response.getEntity(Emp1.class);
		            System.out.println(" Object as request - response " + u.toString());
		      
		        } catch (Exception e) {
		            e.printStackTrace();
		        }   
	}

	

}
