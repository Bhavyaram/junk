package com.test;

import com.myuserservice.User;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String URL = "http://localhost:8080/MyUserService/svc/myuserservice/users/1";
			try {
	            
	            
	         
	            ClientConfig clientConfig = new DefaultClientConfig();
	         //   clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, true);
	            Client client = Client.create(clientConfig);
	            WebResource webResource = client.resource(URL);
	            
	            WebResource.Builder builder = webResource.accept("application/json");
	          
	            ClientResponse response = builder.get(ClientResponse.class);
	            if (response.getStatus() != 200) {
	                throw new RuntimeException("Failed : HTTP error code : "+
	                		response.getStatus());
	            }
	            String u = response.getEntity(String.class);
	            System.out.println(" Name " + u);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }    
			
			
			 String URL1 = "http://localhost:8080/MyUserService/svc/myuserservice/users";
				try {
		            
		            
		         
		            ClientConfig clientConfig = new DefaultClientConfig();
		         //   clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, true);
		            Client client = Client.create(clientConfig);
		            WebResource webResource = client.resource(URL1);
		            
		            WebResource.Builder builder = webResource.accept("application/json");
		          
		            ClientResponse response = builder.get(ClientResponse.class);
		            if (response.getStatus() != 200) {
		                throw new RuntimeException("Failed : HTTP error code : "+
		                		response.getStatus());
		            }
		            User u1 = response.getEntity(User.class);
		            System.out.println(" User " + u1.getUsername());
		        } catch (Exception e) {
		            e.printStackTrace();
		        }    

				
				
		
	}

}
