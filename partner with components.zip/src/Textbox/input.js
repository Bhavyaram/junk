import React, { Component } from 'react';
import './input.css';
class Input extends Component {
    render() {
        return (                                             
                         
                         <span><input type="text" placeholder={this.props.placeholder} className={this.props.className}/>   </span>                                                           
        );
    }
}
export default Input;